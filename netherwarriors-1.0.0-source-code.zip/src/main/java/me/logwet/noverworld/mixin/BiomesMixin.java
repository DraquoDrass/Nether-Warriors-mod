package me.logwet.noverworld.mixin;

import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.Biomes;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static me.logwet.noverworld.NetherStrongholdManager.NETHER_STRONGHOLD;

/*
 * UNUSED
 *
 * Left in the code as a future reference of how to inject Mixins into static initializers.
 */
@Mixin(Biomes.class)
public abstract class BiomesMixin {
	@SuppressWarnings("UnresolvedMixinReference")
	@Inject(method = "<clinit>", at = @At("RETURN"))
	private static void addStronghold(CallbackInfo info) {
		addStrongholdToBiome(Biomes.NETHER_WASTES);
		addStrongholdToBiome(Biomes.BASALT_DELTAS);
		addStrongholdToBiome(Biomes.SOUL_SAND_VALLEY);
		addStrongholdToBiome(Biomes.CRIMSON_FOREST);
		addStrongholdToBiome(Biomes.WARPED_FOREST);
	}

	private static void addStrongholdToBiome(Biome biome) {
		biome.addStructureFeature(NETHER_STRONGHOLD.configure(DefaultFeatureConfig.INSTANCE));
	}
}
