package me.logwet.noverworld.config;

public class MalformedConfigException extends Exception {
    public MalformedConfigException(String message) {
        super(message);
    }
}
